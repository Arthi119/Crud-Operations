package com.hms.repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hms.entities.Doctor;

public interface Doctorrepositary extends JpaRepository<Doctor,Integer>{
	
	

}
