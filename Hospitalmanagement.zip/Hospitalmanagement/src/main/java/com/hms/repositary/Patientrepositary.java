package com.hms.repositary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hms.entities.Patient;
@Repository
public interface Patientrepositary extends JpaRepository<Patient, Integer>
{

}
