package com.hms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hms.entities.Patient;
import com.hms.service.Patientservice;


@RestController
public class Patientcontroller {
	@Autowired
	private Patientservice patientservice;
	
	@PostMapping("/api/addpatient")
	public ResponseEntity<Patient> savePatient(@RequestBody Patient patient)
	{
		return new ResponseEntity<Patient>(patientservice.savePatient(patient),
				HttpStatus.CREATED);
	}
	
	@GetMapping("/api/getallpatients")
	public List<Patient> getAllPatients()
	{
		return patientservice.getAllPatients();
	}
	@GetMapping("/api/getPatientById/{pid}")
	public ResponseEntity<Patient> getPatientById(@PathVariable("pid") int pid)
	{
		return new ResponseEntity<Patient> (patientservice.getPatientById( pid),HttpStatus.OK);
	}
	
	@PutMapping("/api/updatePatientById/{pid}")
	public ResponseEntity<Patient> updatePatient(@PathVariable("pid") int pid, @RequestBody Patient patient) {
	    return new ResponseEntity<Patient>(patientservice.updatePatient(patient, pid), HttpStatus.OK);
	}
	@DeleteMapping("/api/deletePatientById/{pid}")

	public ResponseEntity<String> deletePatient(@PathVariable("pid") int pid)
	{
		patientservice.deletePatient(pid);
		return new ResponseEntity<String> ("employee deleted sucessfully", HttpStatus.OK);
	}
	

}
