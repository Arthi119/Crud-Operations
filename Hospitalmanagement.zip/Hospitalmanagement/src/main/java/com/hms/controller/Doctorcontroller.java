package com.hms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hms.entities.Doctor;

import com.hms.service.Doctorservice;
@RestController
public class Doctorcontroller {
	@Autowired
	private Doctorservice doctorservice;
	
	@PostMapping("/api/adddoctor")
	public ResponseEntity<Doctor> saveDoctor(@RequestBody Doctor doctor)
	{
		return new ResponseEntity<Doctor>(doctorservice.saveDoctor(doctor),HttpStatus.CREATED);
	}
	@PostMapping("/api/assign/{pid}/{id}")
	public ResponseEntity<String> assignPatientTiDoctor(
			@PathVariable("pid") int pid,
			@PathVariable("id") int id)
	{
		return new ResponseEntity<String>(doctorservice.assignPatientToDoctor(pid, id),HttpStatus.CREATED);
	}
			
			
	

}
