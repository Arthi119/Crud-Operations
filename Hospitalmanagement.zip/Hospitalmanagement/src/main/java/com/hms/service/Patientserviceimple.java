package com.hms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hms.entities.Patient;
import com.hms.repositary.Patientrepositary;
@Service
public class Patientserviceimple implements Patientservice {
	@Autowired
	private Patientrepositary patientrepositary;

	@Override
	public Patient savePatient(Patient patient) {
		// TODO Auto-generated method stub
		
		return patientrepositary.save(patient);
	}

	@Override
	public List<Patient> getAllPatients() {
		// TODO Auto-generated method stub
		return patientrepositary.findAll();
	}

	@Override
	public Patient getPatientById(int id) {
		// TODO Auto-generated method stub
		return patientrepositary.findById(id).get();
	}

	@Override
	public Patient updatePatient(Patient patient, int id) {
		// TODO Auto-generated method stub
		Patient existingpatient=patientrepositary.findById(id).get();
		existingpatient.setPname(patient.getPname());
		existingpatient.setPhno(patient.getPhno());
		
		patientrepositary.save(existingpatient);
		return existingpatient;
	
	}

	@Override
	public void deletePatient(int id) {
		// TODO Auto-generated method stub
		patientrepositary.deleteById(id);
		
	}


	}


