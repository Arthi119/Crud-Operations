package com.hms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hms.entities.Doctor;
import com.hms.entities.Patient;
import com.hms.repositary.Doctorrepositary;
import com.hms.repositary.Patientrepositary;
@Service
public class Doctorserviceimple implements Doctorservice {
	@Autowired
	private Doctorrepositary doctorrepositary;
	@Autowired
	private Patientrepositary patientrepositary;

	@Override
	public Doctor saveDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		return doctorrepositary.save(doctor);
	}

	@Override
	public String assignPatientToDoctor(int pid, int id) {
		// TODO Auto-generated method stub
		Patient patient=patientrepositary.findById(pid).get();
		Doctor doctor=doctorrepositary.findById(id).get();
		
		List<Patient> patientlist=new ArrayList<>();
		patientlist.add(patient);
		doctor.setPatients(patientlist);
		patient.setDoctor(doctor);
		patientrepositary.save(patient);
		
		return "assignment has done";
		
		
	}

}
