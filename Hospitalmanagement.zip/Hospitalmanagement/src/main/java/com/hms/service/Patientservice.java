package com.hms.service;

import java.util.List;

import com.hms.entities.Patient;

public interface Patientservice {
	Patient savePatient(Patient patient);
	List<Patient> getAllPatients();
	Patient getPatientById(int id);
	Patient updatePatient(Patient patient,int id);
	void deletePatient(int id);

}
