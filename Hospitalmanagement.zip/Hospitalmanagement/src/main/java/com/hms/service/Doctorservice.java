package com.hms.service;



import com.hms.entities.Doctor;

public interface Doctorservice {
	Doctor saveDoctor(Doctor doctor);
	String assignPatientToDoctor(int pid,int id);

}
