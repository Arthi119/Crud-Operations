package com.hms.entities;



import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;


@Entity
public class Patient {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int pid;
	@Column
	private String pname;
	@Column
	private int phno;
	
	@ManyToOne
	@JsonIgnoreProperties("patient")
    @JoinColumn(name = "id")
    private Doctor doctor;
	public Patient() {
    }

	public Patient(int pid, String pname, int phno, Doctor doctor) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.phno = phno;
		this.doctor = doctor;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getPhno() {
		return phno;
	}

	public void setPhno(int phno) {
		this.phno = phno;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	@Override
	public String toString() {
		return "Patient [pid=" + pid + ", pname=" + pname + ", phno=" + phno + ", doctor=" + doctor + "]";
	}
	
	

}
